export const version = '2.11.1';
export const changeLogLink = 'https://t.me/jiao_long/261';
export const changeLog = `2.11.1 版本说明
1. 修复openapi获取token，token认证
2. 修复环境变量搜索，排序，更新
3. 修复重置应用秘钥
4. 修复环境变量更新时间显示
5. 修复定时默认任务排序
6. task支持运行pyc文件，感谢https://github.com/chiupam
6. 移除ghproxy默认代理，增加新配置ProxyUrl，支持http或者socks代理。例如 http://127.0.0.1:7890
7. 更换JavaScript cdn地址
8. 其他bug修复
`;
