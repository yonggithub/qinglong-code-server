export const version = '2.11.2';
export const changeLogLink = 'https://t.me/jiao_long/261';
export const changeLog = `2.11.2 版本说明
1. 修复更新通知
2. 修复定时任务排序
3. 移除cdn文件
4. 修复日志加载状态
5. python任务测试实时输出
6. 修改定时任务、环境变量唯一值
6. 修复shell克隆仓库状态获取
7. 重构基础镜像，缩减镜像大小、打包时间
`;
